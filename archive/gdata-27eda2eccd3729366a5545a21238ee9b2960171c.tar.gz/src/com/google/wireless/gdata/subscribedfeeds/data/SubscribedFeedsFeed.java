// Copyright 2007 The Android Open Source Project
package com.google.wireless.gdata.subscribedfeeds.data;

import com.google.wireless.gdata.data.Feed;

/**
 * Feed containing contacts.
 */
public class SubscribedFeedsFeed extends Feed {
    /**
     * Creates a new empty events feed.
     */
    public SubscribedFeedsFeed() {
    }
}
