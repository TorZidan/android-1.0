package com.google.wireless.gdata.contacts.data;

import com.google.wireless.gdata.data.Feed;

/**
 * Feed containing contact groups.
 */
public class GroupsFeed extends Feed {
    /**
     * Creates a new empty contact groups feed.
     */
    public GroupsFeed() {
    }
}
