package com.google.wireless.gdata.data;

/**
 * Entry containing information about media entries
 */
public class MediaEntry extends Entry {
  public MediaEntry() {
    super();
  }
}
