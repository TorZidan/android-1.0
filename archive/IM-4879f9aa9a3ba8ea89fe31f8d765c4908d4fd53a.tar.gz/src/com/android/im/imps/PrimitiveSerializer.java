/*
 * Copyright (C) 2007 Esmertec AG.
 * Copyright (C) 2007 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.im.imps;

import java.io.IOException;
import java.io.OutputStream;

/**
 * The <code>PrimitiveSerializer</code> is used format a primitive to expected
 * format such as XML, WBXML or PTS.
 */
public interface PrimitiveSerializer {
    /**
     * Serializes the primitive to the OutputStream in expected format.
     *
     * @param primitive the primitive to format.
     * @param out the OutputStream.
     * @throws IOException
     * @throws SerializerException
     */
    public void serialize(Primitive primitive, OutputStream out)
            throws IOException, SerializerException;
}
