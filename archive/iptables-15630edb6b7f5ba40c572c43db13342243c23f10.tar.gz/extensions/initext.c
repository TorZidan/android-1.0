#include "gen_initext.c"
