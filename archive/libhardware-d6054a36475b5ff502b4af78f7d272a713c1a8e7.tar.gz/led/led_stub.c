#include <hardware/led.h>

int
set_led_state(unsigned color, int on, int off)
{
    return 0;
}
