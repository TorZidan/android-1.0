/*
 * Copyright 2007 The Android Open Source Project
 */
#ifndef LIBFFI_H

#define X86
#include "../src/x86/ffitarget.h"
#include "../include/ffi_real.h"

#endif
