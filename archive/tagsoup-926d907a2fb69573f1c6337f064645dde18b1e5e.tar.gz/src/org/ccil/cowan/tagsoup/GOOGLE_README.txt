This is TagSoup 1.2, downloaded from http://home.ccil.org/~cowan/XML/tagsoup/.

To get the java files included here:
- download tagsoup
- unzip it
- cd into the tagsoup directory
- run ant
- copy the files in src/java and tmp/src