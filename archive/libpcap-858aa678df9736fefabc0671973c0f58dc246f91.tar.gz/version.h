static const char pcap_version_string[] = "libpcap version 0.9.8";
