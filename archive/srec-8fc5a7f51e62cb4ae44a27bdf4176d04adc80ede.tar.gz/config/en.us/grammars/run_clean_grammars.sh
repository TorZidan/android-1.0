echo "Deleting output grammar files to do a clean compilation...."

rm *.phn           >/dev/null 2>&1
rm *.pmap          >/dev/null 2>&1
rm *.script        >/dev/null 2>&1
rm *.g2g           >/dev/null 2>&1
rm *.gram          >/dev/null 2>&1
rm *.Grev2.det.txt >/dev/null 2>&1
rm *.map           >/dev/null 2>&1
rm *.G.txt         >/dev/null 2>&1
rm *.P             >/dev/null 2>&1
rm *.P.txt         >/dev/null 2>&1
rm *.PCLG          >/dev/null 2>&1
rm *.PCLG.txt      >/dev/null 2>&1
rm *.omap          >/dev/null 2>&1
rm *.params        >/dev/null 2>&1
