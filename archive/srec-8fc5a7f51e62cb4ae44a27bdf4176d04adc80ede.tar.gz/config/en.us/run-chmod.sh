chmod 777 ./run-bothtags5.sh
chmod 777 ./run-bothtags5-from-saved.sh
chmod 777 ./run-liveaudio.sh
chmod 777 ./run-set-get-param.sh
chmod 777 ./run-change-sample-rate2.sh
