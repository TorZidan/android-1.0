cd /system/usr/srec
/system/bin/UAPI_SrecTest
