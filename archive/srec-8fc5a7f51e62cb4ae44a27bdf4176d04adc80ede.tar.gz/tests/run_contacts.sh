cd /system/usr/srec
dalvikvm -Xcheck:jni -Xbootclasspath:/system/framework/core.jar:/system/framework/ext.jar:/system/framework/framework.jar:/system/framework/srec-java-tests.jar android.speech.recognition.test.contacts.Main
