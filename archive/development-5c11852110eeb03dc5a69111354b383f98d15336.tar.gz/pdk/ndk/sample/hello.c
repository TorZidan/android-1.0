#include <stdio.h>

int main(int argc, char *argv[])
{
  printf("Hello from the NDK; no user libraries.\n");
  return 0;
}
