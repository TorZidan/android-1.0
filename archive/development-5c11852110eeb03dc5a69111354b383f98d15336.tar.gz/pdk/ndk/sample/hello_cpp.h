#ifndef HELLO_CPP_H
#define HELLO_CPP_H

class Hello
{
public:
    Hello();
    ~Hello();
    void printMessage(char* msg);
};

#endif
