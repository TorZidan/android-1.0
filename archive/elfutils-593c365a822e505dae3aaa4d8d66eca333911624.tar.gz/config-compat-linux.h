#ifndef CONFIG_COMPAT_LINUX_H
#define CONFIG_COMPAT_LINUX_H

#include <byteswap.h>
#include <endian.h>
#include <libintl.h>

#endif
