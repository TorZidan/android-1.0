/* Nothing here.  This is just a testimony of automake inflexibility.  */
