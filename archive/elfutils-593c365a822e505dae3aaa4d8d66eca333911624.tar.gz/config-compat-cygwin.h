#ifndef CONFIG_COMPAT_CYGWIN_H
#define CONFIG_COMPAT_CYGWIN_H

#include <byteswap.h>
#include <endian.h>
#include <libintl.h>

#endif
