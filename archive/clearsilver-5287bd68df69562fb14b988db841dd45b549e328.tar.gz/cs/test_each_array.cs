

<?cs each:sub = Foo.Bar["Baz"] ?>
  <?cs var:sub ?>
<?cs /each ?>
