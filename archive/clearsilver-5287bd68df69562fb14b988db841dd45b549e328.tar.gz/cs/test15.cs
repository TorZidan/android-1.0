
test functions

string.length <?cs var:string.length("This is the end of the world...") ?> == 31

subcount <?cs var:subcount(Foo.Bar.Baz) ?> == 4

len (depreciated) <?cs var:len(Foo.Bar.Baz) ?> == 4


