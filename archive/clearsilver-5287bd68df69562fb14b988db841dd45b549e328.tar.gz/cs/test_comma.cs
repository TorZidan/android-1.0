
Comma tests, evalute both but pass right most as expression result

4: <?cs var:2,4 ?>

also, "do nothing" lparen operator
4: <?cs var:(2,4) ?>

2: <?cs var:(4,2) ?>

3: <?cs var:max((1,3),2) ?>
