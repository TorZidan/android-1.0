<?cs uvar:BlahJs+UrlArg+Title ?>

<?cs escape: "none" ?><?cs uvar:BlahJs+UrlArg+Title ?><?cs /escape ?>
<?cs escape: "html" ?><?cs uvar:BlahJs+UrlArg+Title ?><?cs /escape ?>
<?cs escape: "js" ?><?cs uvar:BlahJs+UrlArg+Title ?><?cs /escape ?>
<?cs escape: "url" ?><?cs uvar:BlahJs+UrlArg+Title ?><?cs /escape ?>
