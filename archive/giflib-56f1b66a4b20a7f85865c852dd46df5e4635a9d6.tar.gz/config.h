
// giflib config.h

#ifndef GIF_CONFIG_H_DEFINED
#define GIF_CONFIG_H_DEFINED

#include <sys/types.h>
#include <stdint.h>
#include <fcntl.h>

typedef uint32_t UINT32;

#endif
