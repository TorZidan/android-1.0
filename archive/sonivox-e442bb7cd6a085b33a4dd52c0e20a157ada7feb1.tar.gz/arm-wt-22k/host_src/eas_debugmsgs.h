/* Auto-generated from source file: eas_chorusdata.c */
/* Auto-generated from source file: eas_xmfdata.c */
/* Auto-generated from source file: eas_mdls.c */
{ 0x19299ed4, 0x00000022, "eas_mdls.c[2561]: #Instruments: %u\n" },
{ 0x19299ed4, 0x00000023, "eas_mdls.c[2562]: #Regions: %u\n" },
{ 0x19299ed4, 0x00000024, "eas_mdls.c[2563]: #Articulations: %u\n" },
{ 0x19299ed4, 0x00000025, "eas_mdls.c[2564]: #Waves: %u\n" },
{ 0x19299ed4, 0x00000026, "eas_mdls.c[2569]: Locale: %lu:%lu:%lu\n" },
{ 0x19299ed4, 0x00000027, "eas_mdls.c[2576]: \tRegion: %u\n" },
{ 0x19299ed4, 0x00000028, "eas_mdls.c[2578]: \t\tm_nGain: %d\n" },
{ 0x19299ed4, 0x00000029, "eas_mdls.c[2579]: \t\trangeLow:rangeHigh %u:%u\n" },
{ 0x19299ed4, 0x0000002a, "eas_mdls.c[2580]: \t\tm_nKeyGroupAndFlags: %04x\n" },
{ 0x19299ed4, 0x0000002b, "eas_mdls.c[2581]: \t\tm_nLoopStart: %u\n" },
{ 0x19299ed4, 0x0000002c, "eas_mdls.c[2582]: \t\tm_nLoopEnd: %u\n" },
{ 0x19299ed4, 0x0000002d, "eas_mdls.c[2583]: \t\tm_nNetTuningInCents: %d\n" },
{ 0x19299ed4, 0x0000002e, "eas_mdls.c[2584]: \t\tArt Index: %u\n" },
{ 0x19299ed4, 0x0000002f, "eas_mdls.c[2585]: \t\tWave Index: %u\n" },
{ 0x19299ed4, 0x00000030, "eas_mdls.c[2597]: Articulation: %u\n" },
{ 0x19299ed4, 0x00000031, "eas_mdls.c[2599]: \t\tm_nEG2toFilterDepth: %d\n" },
{ 0x19299ed4, 0x00000032, "eas_mdls.c[2600]: \t\tm_nEG2toPitchDepth: %d\n" },
{ 0x19299ed4, 0x00000033, "eas_mdls.c[2601]: \t\tm_nFilterCutoffFrequency: %d\n" },
{ 0x19299ed4, 0x00000034, "eas_mdls.c[2602]: \t\tm_nFilterResonance: %u\n" },
{ 0x19299ed4, 0x00000035, "eas_mdls.c[2603]: \t\tm_nLFOAmplitudeDepth: %d\n" },
{ 0x19299ed4, 0x00000036, "eas_mdls.c[2604]: \t\tm_nLFODelayTime: %d\n" },
{ 0x19299ed4, 0x00000037, "eas_mdls.c[2605]: \t\tm_nLFOFrequency: %d\n" },
{ 0x19299ed4, 0x00000038, "eas_mdls.c[2606]: \t\tm_nLFOPitchDepth: %d\n" },
{ 0x19299ed4, 0x00000039, "eas_mdls.c[2607]: \t\tm_nPan: %d\n" },
{ 0x19299ed4, 0x0000003a, "eas_mdls.c[2610]: \t\tm_nAttack: %d\n" },
{ 0x19299ed4, 0x0000003b, "eas_mdls.c[2611]: \t\tm_nDecay: %d\n" },
{ 0x19299ed4, 0x0000003c, "eas_mdls.c[2612]: \t\tm_nSustain: %d\n" },
{ 0x19299ed4, 0x0000003d, "eas_mdls.c[2613]: \t\tm_nRelease: %d\n" },
{ 0x19299ed4, 0x0000003e, "eas_mdls.c[2616]: \t\tm_nAttack: %d\n" },
{ 0x19299ed4, 0x0000003f, "eas_mdls.c[2617]: \t\tm_nDecay: %d\n" },
{ 0x19299ed4, 0x00000040, "eas_mdls.c[2618]: \t\tm_nSustain: %d\n" },
{ 0x19299ed4, 0x00000041, "eas_mdls.c[2619]: \t\tm_nRelease: %d\n" },
{ 0x19299ed4, 0x00000042, "eas_mdls.c[2626]: Wave Index: %d\n" },
{ 0x19299ed4, 0x00000043, "eas_mdls.c[2627]: \tSize %u\n" },
{ 0x19299ed4, 0x00000044, "eas_mdls.c[2628]: \tPointer %08lx\n" },
/* Auto-generated from source file: eas_mididata.c */
/* Auto-generated from source file: eas_pan.c */
/* Auto-generated from source file: eas_wavefiledata.c */
/* Auto-generated from source file: eas_reverbdata.c */
/* Auto-generated from source file: eas_imelodydata.c */
/* Auto-generated from source file: eas_ota.c */
/* Auto-generated from source file: eas_mixbuf.c */
/* Auto-generated from source file: eas_tcdata.c */
/* Auto-generated from source file: jet.c */
/* Auto-generated from source file: eas_rtttl.c */
/* Auto-generated from source file: eas_reverb.c */
/* Auto-generated from source file: eas_pcmdata.c */
/* Auto-generated from source file: eas_chorus.c */
/* Auto-generated from source file: eas_math.c */
/* Auto-generated from source file: eas_xmf.c */
/* Auto-generated from source file: eas_smfdata.c */
/* Auto-generated from source file: eas_imelody.c */
/* Auto-generated from source file: eas_dlssynth.c */
/* Auto-generated from source file: eas_public.c */
/* Auto-generated from source file: eas_rtttldata.c */
/* Auto-generated from source file: eas_voicemgt.c */
/* Auto-generated from source file: eas_tonecontrol.c */
/* Auto-generated from source file: eas_wtengine.c */
/* Auto-generated from source file: eas_imaadpcm.c */
{ 0x2380b977, 0x00000006, "eas_imaadpcm.c[305]: IMADecoderLocate: Time=%d, samples=%d\n" },
{ 0x2380b977, 0x00000007, "eas_imaadpcm.c[328]: IMADecoderLocate: Looped sample, numBlocks=%d, samplesPerLoop=%d, samplesInLastBlock=%d, samples=%d\n" },
{ 0x2380b977, 0x00000008, "eas_imaadpcm.c[335]: IMADecoderLocate: Byte location in audio = %d\n" },
{ 0x2380b977, 0x00000009, "eas_imaadpcm.c[345]: IMADecoderLocate: bytesLeft = %d\n" },
/* Auto-generated from source file: eas_flog.c */
/* Auto-generated from source file: eas_midi.c */
/* Auto-generated from source file: eas_otadata.c */
/* Auto-generated from source file: eas_ima_tables.c */
/* Auto-generated from source file: eas_data.c */
/* Auto-generated from source file: eas_pcm.c */
/* Auto-generated from source file: eas_mixer.c */
/* Auto-generated from source file: eas_wavefile.c */
/* Auto-generated from source file: eas_wtsynth.c */
/* Auto-generated from source file: eas_smf.c */
/* Auto-generated from source file: eas_wave.c */
/* Auto-generated from source file: eas_hostmm.c */
{ 0x1a54b6e8, 0x00000001, "eas_hostmm.c[586]: Vibrate state: %d\n" },
{ 0x1a54b6e8, 0x00000002, "eas_hostmm.c[601]: LED state: %d\n" },
{ 0x1a54b6e8, 0x00000003, "eas_hostmm.c[616]: Backlight state: %d\n" },
{ 0x1a54b6e8, 0x00000004, "eas_hostmm.c[162]: HWMemCpy: bad amount: %d\n" },
{ 0x1a54b6e8, 0x00000005, "eas_hostmm.c[179]: HWMemSet: bad amount: %d\n" },
{ 0x1a54b6e8, 0x00000006, "eas_hostmm.c[196]: HWMemCmp: bad amount: %d\n" },
/* Auto-generated from source file: eas_config.c */
/* Auto-generated from source file: eas_main.c */
{ 0xe624f4d9, 0x00000005, "eas_main.c[106]: Play length: %d.%03d (secs)\n" },
