/* Auto-generated from source file: eas_chorusdata.c */
/* Auto-generated from source file: eas_imelodydata.c */
/* Auto-generated from source file: eas_mididata.c */
/* Auto-generated from source file: eas_pan.c */
/* Auto-generated from source file: eas_wavefiledata.c */
/* Auto-generated from source file: eas_voicemgt.c */
/* Auto-generated from source file: eas_ota.c */
/* Auto-generated from source file: eas_mixbuf.c */
/* Auto-generated from source file: eas_fmsndlib.c */
/* Auto-generated from source file: eas_rtttl.c */
/* Auto-generated from source file: eas_reverb.c */
/* Auto-generated from source file: eas_fmsynth.c */
/* Auto-generated from source file: eas_pcmdata.c */
/* Auto-generated from source file: eas_chorus.c */
/* Auto-generated from source file: eas_math.c */
/* Auto-generated from source file: eas_fmengine.c */
/* Auto-generated from source file: eas_smfdata.c */
/* Auto-generated from source file: eas_fmtables.c */
/* Auto-generated from source file: eas_imelody.c */
/* Auto-generated from source file: eas_public.c */
/* Auto-generated from source file: eas_rtttldata.c */
/* Auto-generated from source file: eas_reverbdata.c */
/* Auto-generated from source file: eas_imaadpcm.c */
{ 0x2380b977, 0x00000006, "eas_imaadpcm.c[305]: IMADecoderLocate: Time=%d, samples=%d\n" },
{ 0x2380b977, 0x00000007, "eas_imaadpcm.c[328]: IMADecoderLocate: Looped sample, numBlocks=%d, samplesPerLoop=%d, samplesInLastBlock=%d, samples=%d\n" },
{ 0x2380b977, 0x00000008, "eas_imaadpcm.c[335]: IMADecoderLocate: Byte location in audio = %d\n" },
{ 0x2380b977, 0x00000009, "eas_imaadpcm.c[345]: IMADecoderLocate: bytesLeft = %d\n" },
/* Auto-generated from source file: eas_midi.c */
/* Auto-generated from source file: eas_otadata.c */
/* Auto-generated from source file: eas_ima_tables.c */
/* Auto-generated from source file: eas_data.c */
/* Auto-generated from source file: eas_pcm.c */
/* Auto-generated from source file: eas_mixer.c */
/* Auto-generated from source file: eas_wavefile.c */
/* Auto-generated from source file: eas_smf.c */
/* Auto-generated from source file: eas_wave.c */
/* Auto-generated from source file: eas_hostmm.c */
{ 0x1a54b6e8, 0x00000001, "eas_hostmm.c[586]: Vibrate state: %d\n" },
{ 0x1a54b6e8, 0x00000002, "eas_hostmm.c[601]: LED state: %d\n" },
{ 0x1a54b6e8, 0x00000003, "eas_hostmm.c[616]: Backlight state: %d\n" },
/* Auto-generated from source file: eas_config.c */
/* Auto-generated from source file: eas_main.c */
{ 0xe624f4d9, 0x00000005, "eas_main.c[106]: Play length: %d.%03d (secs)\n" },
