
<div id="footer">

<div id="copyright">
<?cs call:custom_copyright() ?>
</div>
<div id="build-info">
<?cs call:custom_buildinfo() ?>
</div>

</div>

