<?cs # appears above the blue bar at the top of every page ?>
<?cs def:custom_masthead() ?>
<?cs /def ?>

<?cs # appears in the blue bar at the top of every page ?>
<?cs def:custom_subhead() ?>
    <?cs if:android.buglink ?>
    <?cs /if ?>
<?cs /def ?>

<?cs # appears on the left side of the blue bar at the bottom of every page ?>
<?cs def:custom_copyright() ?><?cs /def ?>

<?cs def:devdoc_left_nav() ?>
<?cs /def ?>
