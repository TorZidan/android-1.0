[#]  <body class="gc-documentation">
[#]
[#]    [include "/html/_common_page_header.ezt"]
[#]    <div class="g-section g-tpl-180">
[#]
[#]      <a name="gc-toc-anchor"></a>  
[#]      <div class="g-unit g-first" id="gc-toc">
[#]        [include toc_path]
[#]      </div>
[#]      
[#]      <a name="gc-pagecontent-anchor"></a>   
[#]      <div class="g-unit" id="gc-pagecontent">


