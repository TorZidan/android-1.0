#ifndef LSD_H
#define LSD_H

void lsd(char **execs, int num_execs,
		 int list_needed_libs,
		 int print_info,
         char **lib_lookup_dirs, 
         int num_lib_lookup_dirs);

#endif
